package com.yaniv.lec3calc;

public interface BinaryFunction <V1,V2,R>{

    /**
     * This Interface gets 2 Generic types and returns a math result (R).
     * @param val1
     * @param val2
     * @return
     */
    R doBinaryMath(V1 val1,V2 val2);
}
