package com.yaniv.lec3calc;

import java.util.HashMap;
import java.util.Map;

public class CalcMath {

    // Class Properties ->
    private Map<String,Operations> operationsMap = new HashMap<>();
    private Double firstValueFromCalcDisplay;
    private Double secondValueFromCalcDisplay;
    private Double finalResult;
    private Operations operations;
    private String tempOperator;


    // todo: Ctor ->
    public CalcMath()
    {
        // Binary Op ->
        operationsMap.put("+",new Operations.Sum((v1,v2)-> v1 + v2));
        operationsMap.put("-",new Operations.Subtract((v1,v2)-> v1 - v2));
        operationsMap.put("x", new Operations.Multi((v1,v2)-> v1 * v2));
        operationsMap.put("÷", new Operations.Divide((v1,v2)-> v1 / v2));
        // Constant Op ->
        operationsMap.put("π", new Operations.Pie(Math.PI));
        // Unary Op ->
        operationsMap.put("√", new Operations.Sqrt((v1)-> Math.sqrt(v1)));
        operationsMap.put("%", new Operations.Percentage((v1)-> v1/100));
        operationsMap.put("+/-", new Operations.NegativeOperation((v1)-> -v1));
        operationsMap.put("=", new Operations.Equal());
    }

    //todo: Unary math ->
    public void unaryMath(String mathSymbol)
    {
        operations = operationsMap.get(mathSymbol);

        if (operations != null)
        {
            switch (operations.getOpEnum())
            {
                case PERCENTAGE:
                    UnaryFunction<Double, Double> unaryFunction = new Operations.Percentage((v1) -> v1 / 100).getUnaryFunction();
                    finalResult = unaryFunction.unaryMathFunction(firstValueFromCalcDisplay);
                    break;
                case PIE:
                    finalResult = new Operations.Pie(Math.PI).getPieValue();
                    break;
                case SQRT:
                    UnaryFunction<Double, Double> unaryFunction2 = new Operations.Sqrt((v1) -> Math.sqrt(v1)).getUnaryFunction();
                    finalResult =  unaryFunction2.unaryMathFunction(firstValueFromCalcDisplay);
                    break;
                case NEGATIVE:
                    UnaryFunction<Double, Double> unaryFunction3 = new Operations.NegativeOperation((v1) -> -v1).getUnaryFunction();
                    finalResult =  unaryFunction3.unaryMathFunction(firstValueFromCalcDisplay);
                    break;
            }
        }
      }

    //todo: Binary math ->
    public void binaryMath()
    {
        operations = operationsMap.get(tempOperator);
        if (operations != null)
        {
            switch (operations.getOpEnum())
            {
                case DIVIDE:
                    BinaryFunction<Double, Double, Double> binaryFunction = new Operations.Divide((v1, v2) -> v1 / v2).getBinaryFunction();
                    finalResult =  binaryFunction.doBinaryMath(firstValueFromCalcDisplay, secondValueFromCalcDisplay);
                    tempOperator = null;
                    break;
                case MULTI:
                    BinaryFunction<Double, Double, Double> binaryFunction2 = new Operations.Multi((v1, v2) -> v1 * v2).getBinaryFunction();
                    finalResult =  binaryFunction2.doBinaryMath(firstValueFromCalcDisplay, secondValueFromCalcDisplay);
                    tempOperator = null;
                    break;
                case SUBTRACT:
                    BinaryFunction<Double, Double, Double> binaryFunction3 = new Operations.Subtract((v1, v2) -> v1 - v2).getBinaryFunction();
                    finalResult =  binaryFunction3.doBinaryMath(firstValueFromCalcDisplay, secondValueFromCalcDisplay);
                    tempOperator = null;
                    break;
                case SUM:
                    BinaryFunction<Double, Double, Double> binaryFunction4 = new Operations.Sum((v1, v2) -> v1 + v2).getBinaryFunction();
                    finalResult =  binaryFunction4.doBinaryMath(firstValueFromCalcDisplay, secondValueFromCalcDisplay);
                    tempOperator = null;
                    break;
            }
        }

    }


    //todo: Getter & Setters ->
    public Double getFirstValueFromCalcDisplay()
    {
       return this.firstValueFromCalcDisplay;
    }
    public Double getSecondValueFromCalcDisplay()
    {
        return this.secondValueFromCalcDisplay;
    }
    public void setSecondValueFromCalcDisplay(Double secondValueFromCalcDisplay) {
        this.secondValueFromCalcDisplay = secondValueFromCalcDisplay;
    }
    public void setTempOperator(String operatorSymbol)
    {
        this.tempOperator = operatorSymbol;
    }
    public String getTempOperator()
    {
        return tempOperator;
    }
    public void setFirstValueFromCalcDisplay(Double firstValueFromCalcDisplay) {
        this.firstValueFromCalcDisplay = firstValueFromCalcDisplay;
    }
    public Double getFinalResult() {
        return finalResult;
    }
}
