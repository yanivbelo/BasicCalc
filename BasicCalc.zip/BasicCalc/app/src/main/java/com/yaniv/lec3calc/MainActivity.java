package com.yaniv.lec3calc;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvDisplay;
    Button divideBtn,multiBtn,sumBtn,subtractBtn;
    private boolean isFirstNamTap = true;
    private boolean hasDot;
    private CalcMath calcMath = new CalcMath();
    private String btnOperatorID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvDisplay = findViewById(R.id.tvDisplay);
        divideBtn = findViewById(R.id.btnDivide);
        multiBtn = findViewById(R.id.btnMult);
        sumBtn = findViewById(R.id.btnPlus);
        subtractBtn = findViewById(R.id.btnMinus);
    }

    //todo: Operators Listener ->
    @SuppressLint("ResourceType")
    public void operatorListener(View view)
    {
        //todo: getting the Btn text ->
        btnOperatorID = getBtnValue(view); // get the Btn text.

        //todo: filtering only the Unary operators ->
        if (tvDisplay != null && btnOperatorID.equals("π") || btnOperatorID.equals("√")
                           || btnOperatorID.equals("%") || btnOperatorID.equals("+/-"))
        {
            /**
             *  Only if we have a first value in calc display, save it to the Model 'tempResult'
             *  property (for later use in the mathAction).
             */
            calcMath.setFirstValueFromCalcDisplay(getTextViewValue());

            // Getting from Model the result value ->
            Double tempResult = calcMath.getFirstValueFromCalcDisplay();

            /**
             * Injecting the Model the Symbol Operator we got from the View.
             * and preforming the Math Action.
             */
            calcMath.unaryMath(btnOperatorID);


            if (tempResult != null)
            {
                /**
                 *  1) calcMath.getTempResult()  --> gives Double result value.
                 *  2) setTextViewValue(calcMath.getTempResult()) --> convert it to String.
                 *  3) setText(setTextViewValue(calcMath.getTempResult())) -- > insert to TextView
                */
              tvDisplay.setText(setTextViewValue(calcMath.getFinalResult()));
            }
        }

        //todo: filtering only the Binary operators ->
        if (tvDisplay != null && btnOperatorID.equals("+") || btnOperatorID.equals("-") ||
        btnOperatorID.equals("x") || btnOperatorID.equals("÷") && calcMath.getTempOperator() == null)
        {
            calcMath.setTempOperator(btnOperatorID);
            calcMath.setFirstValueFromCalcDisplay(getTextViewValue());
            System.out.println("line 78 -> "+ getTextViewValue());

            // for making sure we don't Append the new Operands after the Operator selected...
            isFirstNamTap = true;

            /**
             *  checking what Operator Btn was pressed , for changing the Btn Background Tint color.
             *  for user to know what Operator is Active.
             */
            switch (view.getId())
            {
                case 2131165262: // if its Divide Btn
                    divideBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFB86801")));
                    break;
                case 2131165266: // if its Multiply Btn
                    multiBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFB86801")));
                    break;
                case 2131165269: // if its Sum Btn
                    sumBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFB86801")));
                    break;
                case 2131165265: // if its Subtract Btn
                    subtractBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFB86801")));
                    break;
                case 2131165264: // if its Equal Btn -> resetting to original color.
                    setDefaultBtnColor();
                    break;
            }
        }

        //todo: Result case ->
        if (tvDisplay != null && btnOperatorID.equals("="))
        {
            setDefaultBtnColor();
            calcMath.binaryMath();
            tvDisplay.setText(setTextViewValue(calcMath.getFinalResult()));
            //todo: for supporting chaining math actions.
            calcMath.setFirstValueFromCalcDisplay(getTextViewValue());
            isFirstNamTap = true;
        }
    }

    //todo: method delete each time the last char from calc display (TextView String value) ->
    public void backSpace(View view)
    {
        /**
         * Algorithm:
         * tvDisplay.getText().toString() --> gives the current value of calc display as 'String'.
         * that 'String' result than pass to this method : deleteLastChar(String string).
         * the result of that method is deletion of the last char of that String parameter injection.
         * than, we make sure with a 'condition', if the user deleted all chars - add a "0" to display.
         * lastly , that modified String is inserted to the TextView for display on calc.
         *
         * @param view
         */
        String tempStringValueResult = deleteLastChar(tvDisplay.getText().toString());
        if (tempStringValueResult == null || tempStringValueResult.equals(""))
        {
            clear(view);
        }
        else
        {
            tvDisplay.setText(tempStringValueResult);
        }
    }

    //todo: Method clears all Display field ->
    public void clear(View view)
    {
        tvDisplay.setText("0");
        isFirstNamTap = true;
        hasDot = false;
        setDefaultBtnColor(); // resetting the Operators Btn to Default colors.
        calcMath.setTempOperator(""); // reset the property in 'Model'.
    }

    //todo: Method 'Listener' for Num keypad pressed ->
    public void digitTapped(View view)
    {
        if (isFirstNamTap) //validation if this is the first time we type Num
        {
            tvDisplay.setText("");
        }

        String btnNumValue = getBtnValue(view); //calling method in line 96
        tvDisplay.append(btnNumValue);
        isFirstNamTap = false; //updating the boolean flag that its not the first time.

        //todo: checks if this is the second round of input from user ->
        if (calcMath.getTempOperator() != null)
        {
            calcMath.setSecondValueFromCalcDisplay(getTextViewValue());
            System.out.println("line 167 -> "+ getTextViewValue());
        }
    }

    /**
     * Algorithms:
     * --> 'tvDisplay.getText()'  , gives us the char[] of calc display.
     * --> 'tvDisplay.getText().charAt()' , takes us to the specific index location (End of chars[]).
     *     'charAt(tvDisplay.getText().length()-1)'.
     * --> != '.' && !hasDot -> only if the previous char is not a dot or if we already have 1 dot in
     *     chars[] , only than do ->
     *
     * @param view
     */
    public void decimalTapped(View view)
    {
        String btnNumValue = getBtnValue(view);

        if (tvDisplay.getText().charAt(tvDisplay.getText().length()-1) != '.' && !hasDot)
        {
            tvDisplay.append(btnNumValue);
            hasDot = true;
        }
    }

    //todo: method convert view -> btn String value :
    public String getBtnValue(View view)
    {
        Button numBtn = (Button) view;
        CharSequence btnNumber = numBtn.getText();
        return String.valueOf(btnNumber);
    }

    /**
     * delete  the last char at char[] ,from the first index position 0
     * till the next to last position.
     * Condition at line 108 , makes sure that if we deleted a dot the boolean flag is also
     * reset.
     *
     * @param string
     * @return
     */
    public String deleteLastChar(String string)
    {
        String res = null;

        if ((string != null) && (string.length() > 0))
        {
            res = string.substring(0, string.length() - 1);
            if (!res.contains("."))
            {
               hasDot = false;
            }
        }
        return res;
    }

    //todo: Method converts from TextView - > Double value.
    public Double getTextViewValue()
    {
        if (tvDisplay.getText().length() != 0)
        {
            return Double.valueOf(tvDisplay.getText().toString());
        }
        return 0.0;
    }

    //todo: Method converts from Double - > String (for updating the TextView).
    public String setTextViewValue(Double result)
    {

        return String.valueOf(result);
    }

    //todo: reset back the operators Buttons to default color values.
    public void setDefaultBtnColor()
    {
        divideBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1A23D")));
        multiBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1A23D")));
        sumBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1A23D")));
        subtractBtn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F1A23D")));
    }
}