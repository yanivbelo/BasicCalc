package com.yaniv.lec3calc;

import java.util.function.BiFunction;

abstract class Operations{

    protected OperationEnum opEnum;

    //todo: Enum
    public enum OperationEnum
    {
        MULTI,SUM,DIVIDE, SUBTRACT,EQUAL, PERCENTAGE,PIE, SQRT,NEGATIVE
    }

    //todo: Ctor ->
    public Operations()
    {

    }

    //todo: Getter ->
    public OperationEnum getOpEnum()
    {

        return this.opEnum;
    }


    //todo: 'Multi' operation ->
    public static class Multi extends Operations
    {
        /**
         * BinaryFunction.java
         * This Interface gets 2 Generic types and returns a math result (R).
         * R doBinaryMath(V1 val1,V2 val2);
         *
         * @param val1
         * @param val2
         * @return
         */
        private BinaryFunction<Double,Double,Double> binaryFunction;

        //todo: Ctor ->
        public Multi(BinaryFunction<Double,Double,Double> binaryFunction)
        {
            this.binaryFunction = binaryFunction;
            this.opEnum = OperationEnum.MULTI;
        }

        //todo: Getter ->
        public BinaryFunction<Double,Double,Double> getBinaryFunction()
        {
            return this.binaryFunction;
        }
    }

    //todo: 'Divide' operation ->
    public static class Divide extends Operations
    {
        /**
         * BinaryFunction.java
         * This Interface gets 2 Generic types and returns a math result (R).
         * R doBinaryMath(V1 val1,V2 val2);
         *
         * @param val1
         * @param val2
         * @return
         */
        private BinaryFunction<Double,Double,Double> binaryFunction;

        //todo: Ctor ->
        public Divide(BinaryFunction<Double,Double,Double> binaryFunction)
        {
           this.binaryFunction = binaryFunction;
           this.opEnum = OperationEnum.DIVIDE;
        }

        //todo: Getter ->
        public BinaryFunction<Double,Double,Double> getBinaryFunction()
        {
            return this.binaryFunction;
        }
    }

    //todo: 'Sum' operation ->
    public static class Sum extends Operations
    {
        /**
         * BinaryFunction.java
         * This Interface gets 2 Generic types and returns a math result (R).
         * R doBinaryMath(V1 val1,V2 val2);
         *
         * @param val1
         * @param val2
         * @return
         */
        private BinaryFunction<Double,Double,Double> binaryFunction;

        //todo: Ctor ->
        public Sum(BinaryFunction<Double,Double,Double> binaryFunction)
        {
            this.binaryFunction = binaryFunction;
            this.opEnum = OperationEnum.SUM;
        }

        //todo: Getter ->
        public BinaryFunction<Double,Double,Double> getBinaryFunction()
        {
            return this.binaryFunction;
        }
    }

    //todo: 'Subtract' operation ->
    public static class Subtract extends Operations
    {
        /**
         * BinaryFunction.java
         * This Interface gets 2 Generic types and returns a math result (R).
         * R doBinaryMath(V1 val1,V2 val2);
         *
         * @param val1
         * @param val2
         * @return
         */
        private BinaryFunction<Double,Double,Double> binaryFunction;

        //todo: Ctor ->
        public Subtract(BinaryFunction<Double,Double,Double> binaryFunction)
        {
            this.binaryFunction = binaryFunction;
            this.opEnum = OperationEnum.SUBTRACT;
        }

        //todo: Getter ->
        public BinaryFunction<Double,Double,Double> getBinaryFunction()
        {
            return this.binaryFunction;
        }
    }

    //todo: 'Equal' operation ->
    public static class Equal extends Operations
    {
        public Equal() {
            this.opEnum = OperationEnum.EQUAL;
        }
    }

    //todo: 'Percentage' operation ->
    public static class Percentage extends Operations
    {
        /**
         * UnaryFunction.java
         * This interface gets 1 Generic Value and preforms 1 math function on it,
         * and returns the result as <R>.
         *
         * @param val
         * @return
         */
        private UnaryFunction<Double,Double> unaryFunction;

        //todo: Ctor ->
        public Percentage(UnaryFunction<Double,Double> unaryFunction)
        {
            this.unaryFunction = unaryFunction;
            this.opEnum = OperationEnum.PERCENTAGE;
        }

        //todo: Getter ->
        public UnaryFunction<Double,Double> getUnaryFunction()
        {

            return this.unaryFunction;
        }
    }

    //todo: 'Pie' operation ->
    public static class Pie extends Operations
    {
        private Double pieValue;

        //todo: Ctor ->
        public Pie(Double pieValue)
        {
            this.pieValue = pieValue;
            this.opEnum = OperationEnum.PIE;
        }

        //todo: Getter ->
        public Double getPieValue()
        {

            return this.pieValue;
        }
    }

    //todo: 'SQRT' operation ->
    public static class Sqrt extends Operations
    {
        /**
         * UnaryFunction.java
         * This interface gets 1 Generic Value and preforms 1 math function on it,
         * and returns the result as <R>.
         *
         * @param val
         * @return
         */
        UnaryFunction<Double,Double> unaryFunction;

        //todo: Ctor ->
        public Sqrt(UnaryFunction<Double,Double> unaryFunction)
        {
            this.unaryFunction = unaryFunction;
            this.opEnum = OperationEnum.SQRT;
        }

        //todo: Getter ->
        public UnaryFunction<Double,Double> getUnaryFunction()
        {

            return this.unaryFunction;
        }
    }

    //todo: 'SQRT' operation ->
    public static class NegativeOperation extends Operations
    {
        /**
         * UnaryFunction.java
         * This interface gets 1 Generic Value and preforms 1 math function on it,
         * and returns the result as <R>.
         *
         * @param val
         * @return
         */
        UnaryFunction<Double,Double> unaryFunction;

        //todo: Ctor ->
        public NegativeOperation(UnaryFunction<Double,Double> unaryFunction)
        {
            this.unaryFunction = unaryFunction;
            this.opEnum = OperationEnum.NEGATIVE;
        }

        //todo: Getter ->
        public UnaryFunction<Double,Double> getUnaryFunction()
        {

            return this.unaryFunction;
        }
    }
}
