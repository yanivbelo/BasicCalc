package com.yaniv.lec3calc;

public interface UnaryFunction <V1,R> {

    /**
     * This interface gets 1 Generic Value and preforms 1 math function on it,
     * and returns the result as <R>.
     *
     * @param val
     * @return
     */
    R unaryMathFunction(V1 val);
}
